class Animal {
    public void makeSound() {
        System.out.println("The animal makes a sound");
    }
}
